======
This is the STHCraft texture pack, compiled for STHCraft:UE (MC 1.7.10).
======
License:

The STHCraft Resource Pack (Faithful version) is licensed under Calclavia's Educational Public License (as seen in the file LICENSE.txt. By using or interacting with this software in any way shape or form, you agree to the license of this software.

The STHCraft Resource Pack's download contains textures from Vattic's faithful 32x32 pack, which you can find at http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/1223254-faithful-32x32-pack-update-red-cat-clay-1-8
======
Thanks for reading, see you in a hole!
-The Staff
======
